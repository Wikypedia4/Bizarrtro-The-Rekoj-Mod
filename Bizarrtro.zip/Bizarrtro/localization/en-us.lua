return {
	descriptions = {
		Joker = {
			j_bzr_rekoj = {
				name = "Rekoj",
				text = {
					"{C:chips}-4%{} Score Requirement"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_glommyrekoj = {
				name = "Glommy Rekoj",
				text = {
					"{C:chips}-8%{} Score Requirement if played ", "hand contains a {C:attention}Pair{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_ordinaryrekoj = {
				name = "Ordinary Rekoj",
				text = {
					"{C:chips}-12%{} Score Requirement if played ", "hand contains a {C:attention}Three of a Kind{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_calmrekoj = {
				name = "Calm Rekoj",
				text = {
					"{C:chips}-10%{} Score Requirement if played ", "hand contains a {C:attention}Two Pair{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_sensiblerekoj = {
				name = "Sensible Rekoj",
				text = {
					"{C:chips}-12%{} Score Requirement if played ", "hand contains a {C:attention}Straight{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_seriousrekoj = {
				name = "Serious Rekoj",
				text = {
					"{C:chips}-10%{} Score Requirement if played ", "hand contains a {C:attention}Flush{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_honestrekoj = {
				name = "Honest Rekoj",
				text = {
					"{C:mult}-5{} Mult and {X:mult,C:white}X1.2{} Mult if ","played hand contains a {C:attention}Pair{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_naiverekoj = {
				name = "Naive Rekoj",
				text = {
					"{C:mult}-10{} Mult and {X:mult,C:white}X1.7{} Mult if played ","hand contains a {C:attention}Three of a Kind{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_foolishrekoj = {
				name = "Foolish Rekoj",
				text = {
					"{C:mult}-8{} Mult and {X:mult,C:white}X1.5{} Mult if played ","hand contains a {C:attention}Two Pair{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_impartialrekoj = {
				name = "Impartial Rekoj",
				text = {
					"{C:mult}-10{} Mult and {X:mult,C:white}X1.7{} Mult if played ","hand contains a {C:attention}Straight{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_mindlessrekoj = {
				name = "Mindless Rekoj",
				text = {
					"{C:mult}-8{} Mult and {X:mult,C:white}X1.5{} Mult if played ","hand contains a {C:attention}Flush{}"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_charitablerekoj = {
				name = "Charitable Rekoj",
				text = {
					"Played cards with {C:diamonds}Diamond{} suit take"," {C:chips}-3%{} Score Requirement when scored"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_chasterekoj = {
				name = "Chaste Rekoj",
				text = {
					"Played cards with {C:red}Heart{} suit take"," {C:chips}-3%{} Score Requirement when scored"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_patientrekoj = {
				name = "Patient Rekoj",
				text = {
					"Played cards with {C:spades}Spade{} suit take"," {C:chips}-3%{} Score Requirement when scored"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			},
			j_bzr_temperaterekoj = {
				name = "Temperate Rekoj",
				text = {
					"Played cards with {C:clubs}Club{} suit take"," {C:chips}-3%{} Score Requirement when scored"
				},
				unlock = {
					"Win a run with only {C:green}common{} jokers to unlock"
				}
			}
		}
	}
}
