SMODS.Joker {
    key = "mindlessrekoj",
    unlocked = false,
    discovered = true,
    rarity = 1,
    cost = 2,
    atlas = "Jokers",
    pos = { x = 0, y = 2 },
    unlock = function(card, args)
    	if card and args then
  		if args.type == 'win_with_jokers' and args.jokers ~= nil and #args.jokers > 0 then
  			local count = 0
  			for k,j in pairs(args.jokers) do
  				if j:is_rarity("Common") then
  					count = count + 1
  				end
  			end
  			if count >= #args.jokers then
  				return true
  			end
  		end
  	end
  	return false
    end,
    config = { extra = { }},
    loc_vars = function(self, info_queue, card)
	return { vars = { }}
    end,
    calculate = function (self, card, context)
    	 --[[if context.before then
    		return {
    			mult = -8
    		}
    	end]]
    	if context.joker_main and (context.scoring_name == 'Flush' or next(context.poker_hands['Flush'])) then
    		return {
    			mult = -8,
    			xmult = 1.5,
    			xmult_message = {message = "X1.2",
    			colour = G.C.MULT }
    		}
    	end
    	if card ~= nil and context.ante_up and context.ante ~= nil and context.ante > 0 then
    		card.ability.extra_value = (card.ability.extra_value or 0) + 1
		card:set_cost()
		return {
			message = localize('k_val_up'),
			colour = G.C.MONEY,
		}
    	end
    end
}
