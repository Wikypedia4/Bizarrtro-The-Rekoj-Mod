SMODS.Joker {
    key = "rekoj",
    unlocked = false,
    discovered = true,
    rarity = 1,
    cost = 1,
    atlas = "Jokers",
    pos = { x = 0, y = 0 },
    unlock = function(card, args)
    	if card and args then
  		if args.type == 'win_with_jokers' and args.jokers ~= nil and #args.jokers > 0 then
  			local count = 0
  			for k,j in pairs(args.jokers) do
  				if j:is_rarity("Common") then
  					count = count + 1
  				end
  			end
  			if count >= #args.jokers then
  				return true
  			end
  		end
  	end
  	return false
    end,
    config = { extra = { }},
    loc_vars = function(self, info_queue, card)
	return { vars = { }}
    end,
    calculate = function (self, card, context)
    	if context.before and G.GAME.blind ~= nil and G.GAME.blind.chips > 1 then
		G.E_MANAGER:add_event(Event({
		    blockable = false,
    		    blocking = false,
		    trigger = "after", 
		    delay = 2, 
		    func = function() 
			G.GAME.blind.chips = G.GAME.blind.chips - calcPercent(G.GAME.blind.chips, 4)
			G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
			return true 
		    end
		}))
	    	return {
	    		message = "-4%",
	    		colour = G.C.CHIPS
	    	}
    	end
    	if card ~= nil and context.ante_up and context.ante ~= nil and context.ante > 0 then
    		card.ability.extra_value = (card.ability.extra_value or 0) + 1
		card:set_cost()
		return {
			message = localize('k_val_up'),
			colour = G.C.MONEY,
		}
    	end
    end
}
