

function get_current_profile()
	return G.PROFILES[G.SETTINGS.profile]
end

function save_current_profile()
	G:save_settings()
	G.FILE_HANDLER.force = true
end

function calcPercent(value, percent)
	return value * (percent/100)
end
