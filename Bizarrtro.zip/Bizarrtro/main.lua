
BIZR = SMODS.current_mod

SMODS.current_mod.optional_features = {
	retrigger_joker = true,
	cardareas = {
		discard = true,
		deck = true
	}
}

local files = {
	src = {
		list = {
			"utils"
		},
		directory = "src/"
	},
	jokers = {
		list = {
			"rekoj",
			"charitablerekoj",
			"chasterekoj",
			"patientrekoj",
			"temperaterekoj",
			--
			"glommyrekoj",
			"ordinaryrekoj",
			"calmrekoj",
			"sensiblerekoj",
			"seriousrekoj",
			--
			"honestrekoj",
			"naiverekoj",
			"foolishrekoj",
			"impartialrekoj",
			"mindlessrekoj"
			
		},
		directory = "jokers/"
	}
}

SMODS.Atlas({
	key = "modicon",
	path = "bzr_icon.png",
	px = 16,
	py = 16,
})

SMODS.Atlas({
	key = "Jokers",   --atlas key
	path = "bzr_jokers.png", --atlas' path in (yourMod)/assets/1x or (yourMod)/assets/2x
	px = 71/2,          --width of one card
	py = 95/2,          -- height of one card
})

local function load_files(set)
	for i = 1, #files[set].list do
		if files[set].list[i] then
			assert(SMODS.load_file(files[set].directory .. files[set].list[i] .. ".lua"))()
		end
	end
end

for key, value in pairs(files) do
	load_files(key)
end

--[[local success, dpAPI = pcall(require, "debugplus-api")

local logger = { -- Placeholder logger, for when DebugPlus isn't available
    log = print,
    debug = print,
    info = print,
    warn = print,
    error = print
}

if success and dpAPI.isVersionCompatible(1) then -- Make sure DebugPlus is available and compatible
    local debugplus = dpAPI.registerID("bzr")
    logger = debugplus.logger -- Provides the logger object
    
    debugplus.addCommand({
	    name = "instantwin",
	    shortDesc = "win the game!",
	    desc = "This command allow you to win the run!",
	    exec = function (args, rawArgs, dp)
	    	if G.GAME.won == false then
	    		win_game()
			G.GAME.won = true
			return "run win!"
		end
		return "run alreayd win!"
	    end
	})
	
	debugplus.addCommand({
	    name = "triggeranteup",
	    shortDesc = "trigger anteup",
	    desc = "This command allow you to fake an ante up",
	    exec = function (args, rawArgs, dp)
	    	SMODS.calculate_context { ante_up = true, ante = 2 }
	    	return "fake ante up sended!"
	    end
	})
end]]


